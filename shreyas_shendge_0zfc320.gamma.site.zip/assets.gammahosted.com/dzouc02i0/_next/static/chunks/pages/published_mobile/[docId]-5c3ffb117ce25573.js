(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3055], {
        49135: (e, o, i) => {
            "use strict";
            i.r(o), i.d(o, {
                Page: () => s,
                __N_SSG: () => d,
                default: () => r,
                maxDuration: () => c
            });
            var l = i(6029),
                _ = i(91938),
                a = i(6717),
                n = i(29608),
                d = !0;
            let c = 30,
                s = e => {
                    let {
                        docId: o,
                        doc: i,
                        flags: d
                    } = e;
                    return _.$.DEBUG_ENABLED && console.log("%c @@@@@@@@@@@@@@@@@@@@@@@ [PublishedPage MOBILE] docId", "background-color: pink; font-weight: bold", o, i), n.OI.setUA("Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1"), (0, l.jsx)(a.a, {
                        docId: o,
                        doc: i,
                        flags: d
                    })
                },
                r = s
        },
        76255: (e, o, i) => {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/published_mobile/[docId]", function() {
                return i(49135)
            }])
        }
    },
    e => {
        var o = o => e(e.s = o);
        e.O(0, [4909, 394, 7508, 5088, 4624, 8375, 7452, 6717, 636, 6593, 8792], () => o(76255)), _N_E = e.O()
    }
]);
//# sourceMappingURL=[docId]-5c3ffb117ce25573.js.map